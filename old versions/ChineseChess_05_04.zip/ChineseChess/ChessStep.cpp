#include "ChessStep.h"

ChessStep::ChessStep(QObject *parent) : QObject(parent)
{

}


ChessStep::~ChessStep()
{

}

