#ifndef NETWORKGAME_H
#define NETWORKGAME_H

#include "ChessBoard.h"

class NetworkGame : public ChessBoard
{
public:
    NetworkGame();
    ~NetworkGame();
};

#endif // NETWORKGAME_H
