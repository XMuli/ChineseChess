#include "NetworkGame.h"

NetworkGame::NetworkGame()
{

}

NetworkGame::~NetworkGame()
{

}

