#ifndef CHESSPIECES_H
#define CHESSPIECES_H


class ChessPieces
{
public:
    ChessPieces();
    ~ChessPieces();
};

#endif // CHESSPIECES_H
