#include "ChessPieces.h"

ChessPieces::ChessPieces()
{

}

ChessPieces::~ChessPieces()
{

}

